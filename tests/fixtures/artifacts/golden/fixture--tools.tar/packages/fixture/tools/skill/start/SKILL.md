---
name: start
description: Artifact contract fixture.
disable-model-invocation: true
---
# Start

Read [shared data](<_shared/fixture/shared/data/input.txt?mode=read#sample>).
![image](<_shared/fixture/shared/data/image.svg>)

[reference]: <_shared/fixture/shared/data/input.txt> "Title stays unchanged"

[Reference example][reference].

Inline code `../../shared/data/input.txt` stays unchanged.
