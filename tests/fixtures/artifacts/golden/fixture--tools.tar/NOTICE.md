# Artifact notices

- `github.com/fixture/artifacts` — `NOASSERTION`; [LICENSES/github.com%2Ffixture%2Fartifacts.txt](LICENSES/github.com%252Ffixture%252Fartifacts.txt)
