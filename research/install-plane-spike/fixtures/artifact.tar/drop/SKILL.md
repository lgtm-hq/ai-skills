# Drop

An excluded fixture capability.
