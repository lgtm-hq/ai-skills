﻿# Keep

A retained fixture capability.
